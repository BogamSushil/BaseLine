﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FactoryMethod;

namespace Factory_Method_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            VehicleFactory factory = new ConcreteVehicleFactory();

            IVehicleFactory scooter = factory.GetVehicle(Vehicle.Scooter);
            scooter.Drive(10);

            IVehicleFactory bike = factory.GetVehicle(Vehicle.Bike);
            bike.Drive(12);
            Console.ReadLine();
        }
    }
}
