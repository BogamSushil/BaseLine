﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryClass
{
    #region "AbstractFactory interface"

    public interface VehicleFactory
    {
        Bike GetBike(ModelType model);
        Scooter GetScooter(ModelType model);
    }

    #endregion

    #region "AbstractProduct interface"

    public interface Bike
    {
        string Name();
    }
    public interface Scooter
    {
        string Name();
    }
    #endregion

    public enum ModelType
    {
        Reguler,
        Sport
    }


}
