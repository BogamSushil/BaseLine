﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryClass
{
   public class VechileClient
    {
        Bike mBike;
        Scooter mScooter;

        public VechileClient(VehicleFactory facotry, ModelType type)
        {
           mBike = facotry.GetBike(type);
            mScooter = facotry.GetScooter(type);
        }

        public string GetBikeName()
        {
            if (null != mBike)
            {
                return mBike.Name();
            }
            return "No Bike Found For requested Type";
        }
        public string GetScooterName()
        {
            if (null != mScooter)
            {
                return mScooter.Name();
            }
            return "No Scooter Found For requested Type";
        }
    }
}
