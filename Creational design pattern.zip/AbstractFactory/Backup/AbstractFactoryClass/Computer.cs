using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryClass
{
    class Computer
    {        
        private Monitor mMonitor;

        public void AddMonitor(Monitor argeMonitor)
        {
            mMonitor = argeMonitor;
        }

    }
}
