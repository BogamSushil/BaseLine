using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryClass
{
    class DellMonitor : Monitor
    {
        public DellMonitor(string mType)
        {

        }
    }
}
