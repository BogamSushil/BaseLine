using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryClass
{
    class DellComputer : Computer
    {
        public DellComputer(string mName)
        {

        }
    }
}
