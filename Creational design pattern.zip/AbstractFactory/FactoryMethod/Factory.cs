﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FactoryMethod
{

    #region "Interface"
    public interface IVehicleFactory
    {
        void Drive(int Kms);
    }
    #endregion

    #region "Creator"
    public abstract class VehicleFactory
    {
        public abstract IVehicleFactory GetVehicle(Vehicle type);
    }
    #endregion

    public enum Vehicle
    {
        Scooter,
        Bike,
    }
}
