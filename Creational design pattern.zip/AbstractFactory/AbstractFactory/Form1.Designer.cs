namespace AbstractFactory
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.Honda = new System.Windows.Forms.RadioButton();
            this.Bajaj = new System.Windows.Forms.RadioButton();
            this.Sport = new System.Windows.Forms.RadioButton();
            this.Reguler = new System.Windows.Forms.RadioButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(253, 153);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Get Product";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Honda
            // 
            this.Honda.AutoSize = true;
            this.Honda.Location = new System.Drawing.Point(57, 26);
            this.Honda.Name = "Honda";
            this.Honda.Size = new System.Drawing.Size(95, 17);
            this.Honda.TabIndex = 1;
            this.Honda.TabStop = true;
            this.Honda.Text = "Honda Facotry";
            this.Honda.UseVisualStyleBackColor = true;
            // 
            // Bajaj
            // 
            this.Bajaj.AutoSize = true;
            this.Bajaj.Location = new System.Drawing.Point(165, 26);
            this.Bajaj.Name = "Bajaj";
            this.Bajaj.Size = new System.Drawing.Size(86, 17);
            this.Bajaj.TabIndex = 2;
            this.Bajaj.TabStop = true;
            this.Bajaj.Text = "Bajaj Factory";
            this.Bajaj.UseVisualStyleBackColor = true;
            // 
            // Sport
            // 
            this.Sport.AutoSize = true;
            this.Sport.Location = new System.Drawing.Point(67, 72);
            this.Sport.Name = "Sport";
            this.Sport.Size = new System.Drawing.Size(50, 17);
            this.Sport.TabIndex = 4;
            this.Sport.TabStop = true;
            this.Sport.Text = "Sport";
            this.Sport.UseVisualStyleBackColor = true;
            // 
            // Reguler
            // 
            this.Reguler.AutoSize = true;
            this.Reguler.Location = new System.Drawing.Point(166, 72);
            this.Reguler.Name = "Reguler";
            this.Reguler.Size = new System.Drawing.Size(62, 17);
            this.Reguler.TabIndex = 5;
            this.Reguler.TabStop = true;
            this.Reguler.Text = "Reguler";
            this.Reguler.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(57, 123);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 262);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Reguler);
            this.Controls.Add(this.Sport);
            this.Controls.Add(this.Bajaj);
            this.Controls.Add(this.Honda);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton Honda;
        private System.Windows.Forms.RadioButton Bajaj;
        private System.Windows.Forms.RadioButton Sport;
        private System.Windows.Forms.RadioButton Reguler;
        private System.Windows.Forms.ListBox listBox1;
    }
}

