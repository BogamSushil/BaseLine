﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryClass
{

    #region " Concreate Products"
    class SportBike : Bike
    {
        #region Bike Members

        public string Name()
        {
            return "Sport Bike - Name";
        }

        #endregion
    }

    class RegulerBike : Bike
    {
        #region Bike Members

        public string Name()
        {
            return "Reguler Bike - Name";
        }

        #endregion
    }


    class Scooty : Scooter
    {
        #region Scooter Members

        public string Name()
        {
            return "Scooty - Name";
        }

        #endregion
    }

    class RegulerScooter : Scooter
    {
        #region Scooter Members

        public string Name()
        {
            return "Reguler Scooter - Name";
        }

        #endregion
    }

    #endregion

    #region "Concrete Factories"

    public class HondaFactory : VehicleFactory
    {

        #region VehicleFactory Members

        public Bike GetBike(ModelType bike)
        {
            switch (bike)
            {
                case ModelType.Sport:
                    return new SportBike();
                   
                case ModelType.Reguler:
                    return new RegulerBike();
                   
            }
            return null;
        }

        public Scooter GetScooter(ModelType scooter)
        {
            switch (scooter)
            {
                case ModelType.Sport:
                    return new Scooty();
                   
                case ModelType.Reguler:
                    return new RegulerScooter();                   

            }
            return null;
        }

        #endregion
    }

    public class BajajFactory : VehicleFactory
    {
        #region VehicleFactory Members

        public Bike GetBike(ModelType bike)
        {
            switch (bike)
            {
                case ModelType.Sport:
                    return new SportBike();
                    
                case ModelType.Reguler:
                    return new RegulerBike();
                  
            }
            return null;
        }

        public Scooter GetScooter(ModelType scooter)
        {
            switch (scooter)
            {
                case ModelType.Sport:
                    return new Scooty();
                    
                case ModelType.Reguler:
                    return new RegulerScooter();
                   
            }
            return null;
        }

        #endregion
    }


    #endregion
}
