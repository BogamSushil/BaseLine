﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Builder;

namespace Builder_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            PizzaBuilder ha = new HawaiianPizzaBuilder();
            Cook cook = new Cook();
            cook.SetPizzaBuilder(ha);
            cook.ConstructPizza();
            Pizza p = cook.GetPizza();

            PizzaBuilder spicyPizzaBuilder = new SpicyPizzaBuilder();
            cook.SetPizzaBuilder(spicyPizzaBuilder);
            cook.ConstructPizza();
            // create another product
            Pizza spicy = cook.GetPizza();
            Console.ReadLine();
        }
    }
}
