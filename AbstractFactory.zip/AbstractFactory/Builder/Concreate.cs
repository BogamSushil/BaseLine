﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Builder
{
   public class HawaiianPizzaBuilder : PizzaBuilder
    {
        public override void BuildDough()
        {
            pizza.Dough = "cross";
            Console.WriteLine("HawaiianPizzaBuilder - BuildDough '{0}' ", pizza.Dough);
        }
        public override void BuildSauce()
        {
            pizza.Sauce = "mild";
            Console.WriteLine("HawaiianPizzaBuilder - BuildSauce '{0}' ", pizza.Sauce);

        }
        public override void BuildTopping()
        {
            pizza.Topping = "ham+pineapple";
            Console.WriteLine("HawaiianPizzaBuilder - BuildTopping '{0}' ", pizza.Topping);

        }
    }
    public class SpicyPizzaBuilder : PizzaBuilder
    {
        public override void BuildDough()
        {
            pizza.Dough = "pan baked";
            Console.WriteLine("SpicyPizzaBuilder - BuildDough {0}' ", pizza.Dough);

        }
        public override void BuildSauce()
        {
            pizza.Sauce = "hot";
            Console.WriteLine("SpicyPizzaBuilder - BuildSauce {0} ", pizza.Sauce);
        }
        public override void BuildTopping()
        {
            Console.WriteLine("SpicyPizzaBuilder - BuildTopping {0} ", pizza.Topping);
            pizza.Topping = "pepperoni + salami";
        }
    }
    /// <summary>
    /// Director
    /// </summary>
    public class Cook
    {
        private PizzaBuilder _pizzaBuilder;
        public void SetPizzaBuilder(PizzaBuilder pb)
        {
            _pizzaBuilder = pb;
        }
        public Pizza GetPizza()
        {
            return _pizzaBuilder.GetPizza();
        }
        public void ConstructPizza()
        {
            _pizzaBuilder.CreateNewPizzaProduct();
            _pizzaBuilder.BuildDough();
            _pizzaBuilder.BuildSauce();
            _pizzaBuilder.BuildTopping();
        }
    }
}
