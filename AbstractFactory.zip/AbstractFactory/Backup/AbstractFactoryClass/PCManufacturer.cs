using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryClass
{
    abstract class PCManufacturer
    {
        private string name;
        public abstract Computer ProduceComputer(string argName);
        public abstract Monitor ProduceMonitor(string argType);
    }
}
