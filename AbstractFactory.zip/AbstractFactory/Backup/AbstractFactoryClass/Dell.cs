using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryClass
{
    class Dell : PCManufacturer
    {
       
        public override Computer ProduceComputer(string argName)
        {
            return new DellComputer(argName);
        }

        public override Monitor ProduceMonitor(string argType)
        {
            return new DellMonitor(argType);
        }
    }
}
