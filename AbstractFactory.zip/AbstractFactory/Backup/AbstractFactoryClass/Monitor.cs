using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryClass
{
    abstract class Monitor
    {
        
    }
}
