﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AbstractFactoryClass;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            VehicleFactory hondaFactory = new AbstractFactoryClass.HondaFactory();
            AbstractFactoryClass.VechileClient hondaRegulerClient = new VechileClient(hondaFactory, ModelType.Reguler);
            AbstractFactoryClass.VechileClient hondaSportClient = new VechileClient(hondaFactory, ModelType.Sport);

            VehicleFactory bajajFactory = new AbstractFactoryClass.BajajFactory();
            AbstractFactoryClass.VechileClient bajajRegulerClient = new VechileClient(bajajFactory, ModelType.Reguler);
            AbstractFactoryClass.VechileClient bajajSportClient = new VechileClient(bajajFactory, ModelType.Sport);

            Console.WriteLine("******************** Honda Reguler**************************");
            Console.WriteLine(hondaRegulerClient.GetBikeName());
            Console.WriteLine(hondaRegulerClient.GetScooterName());

            Console.WriteLine("******************** Honda Sport**************************");
            Console.WriteLine(hondaSportClient.GetBikeName());
            Console.WriteLine(hondaSportClient.GetScooterName());

            Console.WriteLine("******************** Bajaj Reguler**************************");
            Console.WriteLine(bajajRegulerClient.GetBikeName());
            Console.WriteLine(bajajRegulerClient.GetScooterName());

            Console.WriteLine("******************** Bajaj Sport**************************");
            Console.WriteLine(bajajSportClient.GetBikeName());
            Console.WriteLine(bajajSportClient.GetScooterName());

            Console.ReadLine();

        }
    }
}
