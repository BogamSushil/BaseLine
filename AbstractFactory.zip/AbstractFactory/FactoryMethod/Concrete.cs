﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FactoryMethod
{

    #region "Concreate Product classes"
    class Scooter : IVehicleFactory
    {
        #region IVehicleFactory Members

        public void Drive(int Kms)
        {
            Console.WriteLine("Drive the Scooter: '{0}' Kms ", Kms);
        }

        #endregion
    }

    class Bike : IVehicleFactory
    {
        #region IVehicleFactory Members

        public void Drive(int Kms)
        {
            Console.WriteLine("Drive the Bike: '{0}' Kms ", Kms);
        }

        #endregion
    }
    #endregion

    #region "Concreate Creator" 
    public class ConcreteVehicleFactory : VehicleFactory
    {
        public override IVehicleFactory GetVehicle(Vehicle type)
        {
            switch (type)
            {
                case Vehicle.Scooter:
                    return new Scooter();
                    
                case Vehicle.Bike:
                    return new Bike();
                

            }
            return null;
        }
    }
    #endregion

}
